---
name: "site-cinematografico"
description: "Cria sites cinematográficos para empresas: landing page com produto 3D animado pelo scroll (estilo Apple), do briefing ao vídeo, quadros, página e publicação."
---

# Site Cinematográfico

Esta skill produz landing pages premium em que um "objeto herói" (hambúrguer, lata, perfume, carro, kebab...) gira, explode ou se monta conforme a pessoa rola a página. A técnica: um vídeo curto gerado por IA vira uma sequência de imagens, que é desenhada num `<canvas>` de acordo com o progresso do scroll.

Siga as 6 etapas na ordem. Não pule o briefing: é ele que faz o site parecer feito sob medida e não um template.

---

## Etapa 1 — Briefing

Pergunte (ou deduza do pedido) e registre em `briefing.md`:

- **Negócio:** nome, ramo, cidade, público, diferencial.
- **Objetivo da página:** pedido no WhatsApp, reserva, compra, captura de lead.
- **Objeto herói:** o produto que vai animar. Deve ser UM objeto marcante, fotogênico e reconhecível.
- **Tipo de animação:** escolha uma:
  - `explode` — camadas se separam (ideal para comida montada, eletrônicos);
  - `assemble` — peças se juntam (o inverso, ótimo para revelação);
  - `rotate` — giro de 180–360° (bebidas, perfumes, calçados);
  - `unwrap` — abre/desembrulha (wraps, presentes, embalagens).
- **Tom:** premium, divertido, rústico, tech, artesanal.

Depois defina a **direção de arte**:

- Paleta de 3–4 cores, com a **cor de fundo exata (hex)** — o vídeo será gerado nessa mesma cor para emendar sem borda.
- Duas fontes do Google Fonts com personalidade (uma display para títulos, uma legível para texto). Evite Inter/Roboto/Arial como título.
- **Roteiro do scroll** em 3–5 "beats": para cada faixa do progresso (ex.: 0–25%, 25–50%...), o que o objeto faz e qual frase curta aparece.

Exemplo de roteiro (hamburgueria, `explode`):
- 0–20%: burger inteiro → "Feito na brasa. Do jeito certo."
- 20–50%: pão sobe, camadas se abrem → "Blend 180g de costela"
- 50–80%: camadas totalmente separadas → "Cheddar inglês, bacon defumado, pão brioche"
- 80–100%: volta a fechar → botão "Peça agora"

## Etapa 2 — Vídeo do objeto herói

Use a skill **video-objeto-heroi** para escrever o prompt e gerar o vídeo. Resumo do que precisa sair:

- 5–8 segundos, câmera **totalmente parada**, sem cortes.
- Fundo liso na cor hex do briefing, sem texto, sem mãos, sem logos de terceiros.
- Versão 16:9 (desktop) e, se possível, 9:16 (celular).
- Salve como `assets/hero.mp4` (e `assets/hero-mobile.mp4`).

Se não houver ferramenta de geração de vídeo nesta sessão (ex.: Higgsfield), entregue os prompts prontos ao usuário e peça que ele coloque o vídeo em `assets/hero.mp4` antes de seguir.

## Etapa 3 — Vídeo em quadros

Confira a duração e gere os quadros em WebP (leve e nítido):

```bash
ffprobe -v error -show_entries format=duration -of csv=p=0 assets/hero.mp4
mkdir -p frames/desktop frames/mobile
# desktop: ~150 quadros, 1600px de largura
ffmpeg -i assets/hero.mp4 -vf "fps=24,scale=1600:-2" -c:v libwebp -quality 72 frames/desktop/f_%04d.webp
# celular: menor e mais leve (use hero-mobile.mp4 se existir)
ffmpeg -i assets/hero.mp4 -vf "fps=20,scale=800:-2" -c:v libwebp -quality 65 frames/mobile/f_%04d.webp
ls frames/desktop | wc -l; du -sh frames/*
```

Metas: 100–180 quadros; pasta desktop abaixo de ~8 MB e mobile abaixo de ~3 MB. Se passar, reduza `fps`, `scale` ou `quality`. Anote o número exato de quadros de cada pasta.

Se o objeto "pula" ou o fundo muda de tom entre quadros, o vídeo não serve: volte à Etapa 2.

## Etapa 4 — Montar a página

Arquivo único `index.html` (CSS e JS no mesmo arquivo), sem frameworks obrigatórios. Estrutura recomendada:

1. **Hero com scroll animado** (seção alta, ~400vh, com área "sticky").
2. **Diferenciais** — 3 cartões curtos.
3. **Cardápio/produtos ou serviços** — com preços se fizer sentido.
4. **Prova social** — apenas depoimentos e números REAIS fornecidos pelo cliente. Nunca invente avaliações. Se não houver, omita a seção.
5. **CTA final** + rodapé com endereço, horário, redes e botão de WhatsApp.

### Código base do scroll em canvas

```html
<section id="hero" class="hero">
  <div class="sticky">
    <canvas id="seq"></canvas>
    <div class="beat" data-from="0" data-to="0.2"><h1>Feito na brasa.</h1></div>
    <div class="beat" data-from="0.2" data-to="0.5"><h2>Blend 180g de costela</h2></div>
    <div class="beat" data-from="0.8" data-to="1.01"><a class="cta" href="#pedido">Peça agora</a></div>
  </div>
</section>

<style>
  .hero { height: 400vh; position: relative; background: var(--bg); }
  .sticky { position: sticky; top: 0; height: 100vh; overflow: hidden; }
  #seq { width: 100%; height: 100%; display: block; }
  .beat { position: absolute; inset: auto 0 12vh 0; text-align: center;
          opacity: 0; transform: translateY(24px);
          transition: opacity .5s ease, transform .5s ease; pointer-events: none; }
  .beat.on { opacity: 1; transform: none; pointer-events: auto; }
</style>

<script>
(() => {
  const isMobile = matchMedia('(max-width: 768px)').matches;
  const FRAMES = isMobile ? 120 : 150;           // número exato de quadros gerados
  const DIR = isMobile ? 'frames/mobile' : 'frames/desktop';
  const src = i => `${DIR}/f_${String(i + 1).padStart(4, '0')}.webp`;

  const hero = document.getElementById('hero');
  const canvas = document.getElementById('seq');
  const ctx = canvas.getContext('2d');
  const beats = [...document.querySelectorAll('.beat')];
  const imgs = new Array(FRAMES);
  let current = -1, ticking = false;

  function resize() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = innerWidth * dpr; canvas.height = innerHeight * dpr;
    current = -1; render();
  }

  function draw(img) {                            // efeito "cover"
    const cw = canvas.width, ch = canvas.height;
    const s = Math.max(cw / img.width, ch / img.height);
    const w = img.width * s, h = img.height * s;
    ctx.clearRect(0, 0, cw, ch);
    ctx.drawImage(img, (cw - w) / 2, (ch - h) / 2, w, h);
  }

  function progress() {
    const r = hero.getBoundingClientRect();
    return Math.min(1, Math.max(0, -r.top / (r.height - innerHeight)));
  }

  function render() {
    ticking = false;
    const p = progress();
    let i = Math.round(p * (FRAMES - 1));
    while (i > 0 && !(imgs[i] && imgs[i].complete)) i--;  // usa o último já carregado
    if (i !== current && imgs[i] && imgs[i].complete) { draw(imgs[i]); current = i; }
    beats.forEach(b => b.classList.toggle('on', p >= +b.dataset.from && p < +b.dataset.to));
  }

  function load(i) { const im = new Image(); im.decoding = 'async'; im.src = src(i); imgs[i] = im; return im; }

  load(0).onload = () => { resize(); for (let i = 1; i < FRAMES; i++) load(i).onload = render; };

  if (matchMedia('(prefers-reduced-motion: reduce)').matches) {
    hero.style.height = '100vh';                  // mostra só um quadro, sem animação
  }
  addEventListener('scroll', () => { if (!ticking) { ticking = true; requestAnimationFrame(render); } }, { passive: true });
  addEventListener('resize', resize);
})();
</script>
```

### Regras de design

- O fundo da página no hero deve ser **idêntico** ao fundo do vídeo (mesmo hex).
- Títulos grandes e curtos (até 6 palavras). Uma ideia por beat.
- Seções abaixo do hero com entrada suave (IntersectionObserver + classe que faz fade/translate).
- Botões grandes, contraste alto, CTA visível no fim do hero e no rodapé.
- Mobile em primeiro lugar: teste a 390px de largura; texto nunca em cima da parte principal do objeto.
- Use `loading="lazy"` em imagens fora do hero e `<link rel="preload">` no primeiro quadro.
- Metatags: `<title>`, `description`, Open Graph com uma imagem (pode ser o quadro do meio).

## Etapa 5 — Conferir

Antes de entregar:

- Rode um servidor local (`python3 -m http.server 8080`) e abra a página; se houver navegador disponível, role do início ao fim no desktop e com largura 390px.
- O objeto anima suave, sem tela branca nem pulos? Os textos aparecem nos momentos certos?
- Peso total: hero desktop < ~8 MB, mobile < ~3 MB. Primeiro quadro aparece em menos de 2 s.
- Links de WhatsApp (`https://wa.me/55DDDNUMERO?text=...`), telefone e mapa funcionando.
- Nenhum dado inventado (preço, avaliação, endereço). O que faltar, marque como `[PREENCHER]` e avise o usuário.

## Etapa 6 — Entregar e publicar

- Estrutura final:
  ```
  projeto/
    index.html
    assets/hero.mp4
    frames/desktop/*.webp
    frames/mobile/*.webp
    briefing.md
  ```
- Publique em uma hospedagem estática (Vercel, Netlify, GitHub Pages ou a que o usuário preferir) e devolva o link.
- Termine com um resumo curto: o que foi feito, o link e o que o cliente ainda precisa enviar (fotos reais, preços, depoimentos).

## Variações rápidas

- **Dois objetos:** duas seções `.hero` independentes, cada uma com sua pasta de quadros.
- **Portfólio para vender o serviço:** página com 3–4 mini-demos (uma por nicho: hamburgueria, bebida, cosmético, imobiliária), cada uma com seu objeto herói.
- **Sem vídeo disponível:** use uma imagem do produto com parallax e zoom no scroll como versão provisória, avisando o usuário.