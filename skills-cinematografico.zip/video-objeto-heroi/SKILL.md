---
name: "video-objeto-heroi"
description: "Escreve prompts e gera o vídeo do 'objeto herói' (produto girando, explodindo ou se montando) em fundo liso, pronto para virar animação de scroll em sites."
---

# Vídeo do Objeto Herói

Gera o vídeo curto que vira a animação de scroll de um site cinematográfico. O vídeo só funciona se for **estável**: câmera parada, fundo liso e constante, um único objeto no centro.

## 1. Dados de entrada

- Objeto (ex.: "hambúrguer artesanal com cheddar e bacon").
- Tipo de movimento: `explode`, `assemble`, `rotate` ou `unwrap`.
- Cor de fundo hex (a mesma da página).
- Estilo de luz: estúdio premium, quente rústico, neon tech, luz natural suave.

## 2. Melhor fluxo: imagem primeiro, depois vídeo

1. **Gere o quadro inicial** (imagem) com o objeto perfeito, centralizado, fundo na cor hex.
2. **Para `explode`/`unwrap`:** use essa imagem como quadro inicial do vídeo.
   **Para `assemble`:** gere também a imagem final montada e use como último quadro (ou gere `explode` e inverta o vídeo depois com `ffmpeg -i in.mp4 -vf reverse out.mp4`).
3. Gere o vídeo a partir da imagem (image-to-video). Isso garante consistência de forma e cor.

Se a ferramenta Higgsfield estiver disponível, use-a: confira os modelos de imagem e vídeo disponíveis, escolha um modelo de vídeo que aceite quadro inicial (e final, se for `assemble`), e estime o custo antes de gerar. Gere 2 variações e escolha a mais estável. Sem ferramenta de geração, entregue os prompts ao usuário para ele gerar onde preferir.

## 3. Modelo de prompt (em inglês, funciona melhor)

**Imagem inicial:**
```
Product hero shot of [OBJECT], perfectly centered, floating, on a seamless solid [HEX COLOR] background, [LIGHTING] studio lighting, soft shadow beneath, ultra-detailed textures, commercial food/product photography, 16:9, no text, no logos, no hands, no props.
```

**Vídeo — explode:**
```
Locked-off static camera, no camera movement. [OBJECT] centered on a seamless solid [HEX COLOR] background. The layers slowly separate vertically in an elegant exploded view, each ingredient floating apart with small crumbs and particles, smooth slow motion, consistent lighting, background stays perfectly uniform. No text, no hands, no cuts. 6 seconds.
```

**Vídeo — rotate:**
```
Locked-off static camera. [OBJECT] centered on a seamless solid [HEX COLOR] background, slowly rotating 360 degrees on its vertical axis at constant speed, studio lighting with subtle reflections, background perfectly uniform. No text, no hands, no cuts. 6 seconds.
```

**Vídeo — unwrap:**
```
Locked-off static camera. [OBJECT] centered on a seamless solid [HEX COLOR] background, the wrapping slowly unfolds and opens to reveal the inside, smooth slow motion, particles gently floating, background perfectly uniform. No text, no hands, no cuts. 6 seconds.
```

Regras do prompt: sempre "locked-off static camera", sempre "seamless solid background" com o hex, nunca pedir texto ou logo no vídeo (o texto vai no HTML), sem pessoas.

## 4. Checagem do vídeo

Antes de entregar, extraia alguns quadros e olhe:

```bash
mkdir -p check && ffmpeg -v error -i hero.mp4 -vf "fps=1,scale=480:-2,tile=4x2" check/grid.png
```

Reprove e gere de novo se: a câmera se move, o fundo muda de cor ou tem vinheta forte, o objeto deforma/derrete, aparece texto estranho, ou o objeto sai do centro.

## 5. Ajustes finais

- Igualar o fundo à cor da página (se ficou levemente diferente), ajustando cor ou cortando bordas:
  `ffmpeg -i hero.mp4 -vf "crop=iw*0.9:ih*0.9" hero_crop.mp4`
- Versão celular 9:16: gere outro vídeo em 9:16 com o mesmo prompt, ou recorte o centro:
  `ffmpeg -i hero.mp4 -vf "crop=ih*9/16:ih" hero-mobile.mp4`
- Salve como `assets/hero.mp4` e `assets/hero-mobile.mp4`.

Entregue: o vídeo aprovado, o prompt usado (para refazer depois) e a cor hex exata do fundo.